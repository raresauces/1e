
#ifndef __TCPA_DEFINES_H__
#define __TCPA_DEFINES_H__

#warning including deprecated header file tcpa_defines.h

#endif
